// import Header from "@/components/header";
// import Footer from "@/components/footer";

// export default function HomeLayout() {
//   return (
//     <div className="bg-white dark:bg-gray-900">
//       <Header />
//       <Footer />
//     </div>
//   );
// }
